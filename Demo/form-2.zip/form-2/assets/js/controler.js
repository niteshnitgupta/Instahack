function findPorters(latLng) {
	var data = {action: 'findPorters', location:latLng};
	var request = $.ajax({
		// url: 'api.php',
		url: 'http://192.168.6.167:8888/Instahack/porter_server.php',
		method: 'POST',
		dataType: 'jsonp',
		data: data,
		success: function(data) {
			data = JSON.parse(data);
			// data.porters = JSON.parse(data.porters);
			if(data.response == "ok") {

				console.log(data.porters.length);
				for(var i=0; i<data.porters.length; i++) {
					console.log(data.porters[i]);
				};
				var map = new google.maps.Map(document.getElementById('map'), {
				  center: latLng,
				  zoom: 14
				});

				var center = map.getCenter();

				var marker = new google.maps.Marker({
				    position: latLng,
				    map: map,
				    title: 'Matched Location'
				});
				
				google.maps.event.addListenerOnce(map, 'idle', function() {
				    google.maps.event.trigger(map, 'resize');
				  map.setCenter(center);
				});

				var circle = new google.maps.Circle({
				  map: map,
				  radius: 1200,    // 10 miles in metres
				  fillOpacity: 0.3,
				  strokeOpacity: 0.3,
				  strokeColor: '#5394F1',
				  fillColor: '#5394F1'
				});
				circle.bindTo('center', marker, 'position');
			}
		},
		fail: function() {
			alert();
		}

	});
}